package alejandro.figueroa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoConsultoriosApplicationTests {

	@Test
	void contextLoads() {
	}

}
